s = Procedural.CircleShape():setNumSeg(64):setRadius(2):realizeShape()
tests:addShape(s)