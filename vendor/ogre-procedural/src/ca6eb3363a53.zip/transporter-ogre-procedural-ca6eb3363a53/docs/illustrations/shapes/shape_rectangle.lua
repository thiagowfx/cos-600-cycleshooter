s = Procedural.RectangleShape():setHeight(2):setWidth(4):realizeShape()
tests:addShape(s)