s = Procedural.TriangleShape():setLength(3):realizeShape()
tests:addShape(s)