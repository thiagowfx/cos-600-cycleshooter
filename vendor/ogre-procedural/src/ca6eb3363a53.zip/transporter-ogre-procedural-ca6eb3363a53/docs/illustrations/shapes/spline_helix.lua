p = Procedural.HelixPath():setNumSegPath(64):setNumRound(3):setHeight(1.5):realizePath():translate(0, -2.2, 0.0)
tests:addPath(p)