s = Procedural.Shape():addPoint(-1,-1):addPoint(0.5,0):addPoint(-0.5,0):addPoint(1,1)
tests:addShape(s)