s = Procedural.EllipseShape():setNumSeg(64):setRadiusX(2.25):setRadiusY(1.25):realizeShape()
tests:addShape(s)