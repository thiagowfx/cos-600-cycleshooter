mesh = Procedural.TorusGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)