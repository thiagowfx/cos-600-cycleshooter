mesh = Procedural.IcoSphereGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)