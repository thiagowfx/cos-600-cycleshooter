mesh = Procedural.TorusKnotGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)