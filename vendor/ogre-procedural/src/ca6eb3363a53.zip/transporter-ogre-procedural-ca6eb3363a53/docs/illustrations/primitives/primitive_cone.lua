mesh = Procedural.ConeGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)