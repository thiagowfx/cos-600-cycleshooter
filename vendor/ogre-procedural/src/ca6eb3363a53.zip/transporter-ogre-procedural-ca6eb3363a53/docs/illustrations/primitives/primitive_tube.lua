mesh = Procedural.TubeGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)