mesh = Procedural.SphereGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)