mesh = Procedural.CylinderGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)