mesh = Procedural.PlaneGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)