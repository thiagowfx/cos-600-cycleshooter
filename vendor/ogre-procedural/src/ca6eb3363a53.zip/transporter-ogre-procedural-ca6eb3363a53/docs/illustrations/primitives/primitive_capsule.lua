mesh = Procedural.CapsuleGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)