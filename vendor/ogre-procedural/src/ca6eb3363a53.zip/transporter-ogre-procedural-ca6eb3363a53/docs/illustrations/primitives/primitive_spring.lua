mesh = Procedural.SpringGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)