mesh = Procedural.BoxGenerator():setSizeX(1):buildTriangleBuffer()
tests:addTriangleBuffer(mesh)