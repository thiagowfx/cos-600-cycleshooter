mesh = Procedural.RoundedBoxGenerator():buildTriangleBuffer()
tests:addTriangleBuffer(mesh)