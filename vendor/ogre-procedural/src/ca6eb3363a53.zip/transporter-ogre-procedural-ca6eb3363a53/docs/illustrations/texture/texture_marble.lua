buffer = Procedural.TextureBuffer(128)
Procedural.Marble(buffer):process()
tests:addTextureBuffer(buffer)
