buffer = Procedural.TextureBuffer(128)
Procedural.Cell(buffer):setDensity(4):process()
tests:addTextureBuffer(buffer)
