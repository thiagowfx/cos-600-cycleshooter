buffer = Procedural.TextureBuffer(128)
Procedural.Textile(buffer):process()
tests:addTextureBuffer(buffer)
