buffer = Procedural.TextureBuffer(128)
Procedural.Labyrinth(buffer):process()
tests:addTextureBuffer(buffer)
