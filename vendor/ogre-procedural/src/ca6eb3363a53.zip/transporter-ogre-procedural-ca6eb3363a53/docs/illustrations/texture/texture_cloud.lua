buffer = Procedural.TextureBuffer(128)
Procedural.Cloud(buffer):process()
tests:addTextureBuffer(buffer)
