buffer = Procedural.TextureBuffer(128)
Procedural.Wood(buffer):process()
tests:addTextureBuffer(buffer)
