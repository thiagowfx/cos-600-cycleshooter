Ogre %Procedural Manual {#mainpage}
======================

This manual aims to give an overview of what is possible with Ogre %Procedural.

* [How to use](@ref howto)
* [Primitives](@ref primitives)
* [Shapes and paths](@ref shapepath)
* [Extruder](@ref extruder)
* [Textures](@ref textures)