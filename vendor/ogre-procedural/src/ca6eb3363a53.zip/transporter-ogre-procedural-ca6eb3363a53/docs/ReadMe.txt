How to build the docs
---------------------

1. Install doxygen and graphviz and add their bin directory to the system PATH
2. Build the doc target to create the doxygen api docs, illustrations, and manual at the same time